print('long')
